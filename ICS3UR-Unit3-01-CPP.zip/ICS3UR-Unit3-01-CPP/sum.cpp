// Copyright (c) 2019 St. Mother Teresa HS All rights reserved.
//
// Created by Gabriel A
// Created on Nov 2020
// This program calculates the sum of two numbers

#include <iostream>

int main() {
    int numo;
    int numt;
    int sm;

    // input
    std::cout << "We will be calculating the sum of two numbers" << std::endl;
    std::cout << "Enter a number: ";
    std::cin >> numo;
    std::cout << "Enter another number: ";
    std::cin >> numt;

    // process
    sm = numo + numt;

    // output
    std::cout << "" << std::endl;
    std::cout << numo << "+" << numt << "=" << sm << std::endl;
}
